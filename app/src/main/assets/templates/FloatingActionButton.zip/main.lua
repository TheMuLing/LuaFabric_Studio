require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.activity.EdgeToEdge"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatTextView"
import "androidx.coordinatorlayout.widget.CoordinatorLayout"
import "com.google.android.material.appbar.AppBarLayout"
import "com.google.android.material.floatingactionbutton.FloatingActionButton"
import "com.google.android.material.appbar.MaterialToolbar"
import "com.google.android.material.snackbar.Snackbar"

EdgeToEdge.enable(activity)

activity
.setTheme(R.style.Theme_Material3_Blue_NoActionBar)
.setTitle("AppName")
.setContentView(loadlayout("layout"))
.setSupportActionBar(toolbar)
.getSupportActionBar()

function fab.onClick()
  Snackbar
  .make(coordinator, "This a Snackbar", Snackbar.LENGTH_SHORT)
  .show()
end