require "import"
import "android.widget.*"
import "androidx.activity.EdgeToEdge"
import "com.google.android.material.card.MaterialCardView"
import "com.google.android.material.button.MaterialButton"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatImageView"
$ Context = luajava.bindClass "android.content.Context"
$ WindowManager = luajava.bindClass "android.view.WindowManager"
$ Gravity = luajava.bindClass "android.view.Gravity"
$ MotionEvent = luajava.bindClass "android.view.MotionEvent"
$ PixelFormat = luajava.bindClass "android.graphics.PixelFormat"
$ Settings = luajava.bindClass "android.provider.Settings"
$ Intent = luajava.bindClass "android.content.Intent"
$ Uri = luajava.bindClass "android.net.Uri"
$ Build = luajava.bindClass "android.os.Build"
$ EdgeToEdge = luajava.bindClass "androidx.activity.EdgeToEdge"

$ LayoutParams = WindowManager.LayoutParams
$ wmManager = activity.getSystemService(Context.WINDOW_SERVICE)
$ wmParams = LayoutParams()
$ isFloatingBallOpen = false

EdgeToEdge.enable(activity)

activity
.setTheme(R.style.Theme_Material3_Blue_NoActionBar)
.setTitle("AppName")
.setContentView(loadlayout "layout")

-- 悬浮窗类型（兼容不同 API 版本）
if Build.VERSION.SDK_INT >= 26 then
  wmParams.type = LayoutParams.TYPE_APPLICATION_OVERLAY
 else
  wmParams.type = LayoutParams.TYPE_SYSTEM_ALERT
end

wmParams.format = PixelFormat.RGBA_8888
wmParams.gravity = Gravity.LEFT | Gravity.TOP
wmParams.x = activity.getWidth() / 6
wmParams.y = activity.getHeight() / 5
wmParams.width = LayoutParams.WRAP_CONTENT
wmParams.height = LayoutParams.WRAP_CONTENT

-- 悬浮窗权限检查
if Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(activity) then
  Toast.makeText(activity, "请授予本应用 显示悬浮窗 权限以继续", Toast.LENGTH_LONG).show()
  $ intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
  intent.setData(Uri.parse("package:" .. activity.getPackageName()))
  activity.startActivityForResult(intent, 100)
  return false
end

$ floatingBall = loadlayout "xfq"
$ floatingWindow = loadlayout "xfc"

-- 窗口标志位定义
-- 小球模式：不获取焦点，不干扰其他应用输入
$ FLAGS_BALL = LayoutParams.FLAG_NOT_FOCUSABLE | LayoutParams.FLAG_NOT_TOUCH_MODAL
-- 展开模式：获取焦点（支持 EditText 输入），监听外部点击
$ FLAGS_WINDOW = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

-- 辅助函数：更新窗口布局参数
$ function updateLayoutParams(view)
  wmManager.updateViewLayout(view, wmParams)
end

-- 展开悬浮窗（获取焦点，支持编辑框）
$ function expand()
  wmParams.flags = FLAGS_WINDOW
  pcall(function()
    wmManager.removeView(floatingBall)
  end)
  wmManager.addView(floatingWindow, wmParams)
end

-- 最小化悬浮窗（释放焦点给其他应用）
$ function hide()
  wmParams.flags = FLAGS_BALL
  pcall(function()
    wmManager.removeView(floatingWindow)
  end)
  wmManager.addView(floatingBall, wmParams)
end

-- 完全关闭悬浮窗（释放焦点）
$ function exit()
  pcall(function()
    wmManager.removeView(floatingWindow)
  end)
  pcall(function()
    wmManager.removeView(floatingBall)
  end)
  isFloatingBallOpen = false
end

-- 打开悬浮窗按钮事件
function open.onClick()
  if not isFloatingBallOpen then
    wmParams.flags = FLAGS_BALL
    wmManager.addView(floatingBall, wmParams)
    isFloatingBallOpen = true
   else
    Toast.makeText(activity, "悬浮窗已启动", Toast.LENGTH_SHORT).show()
  end
end

-- 关闭按钮事件
function Close.onClick()
  exit()
end

-- 最小化按钮事件
function Min.onClick()
  hide()
end

-- 悬浮球拖动事件
$ ballFirstX, ballFirstY, ballWmX, ballWmY

function Logo.OnTouchListener(v, event)
  $ action = event.getAction()
  if action == MotionEvent.ACTION_DOWN then
    ballFirstX = event.getRawX()
    ballFirstY = event.getRawY()
    ballWmX = wmParams.x
    ballWmY = wmParams.y
   elseif action == MotionEvent.ACTION_MOVE then
    wmParams.x = ballWmX + (event.getRawX() - ballFirstX)
    wmParams.y = ballWmY + (event.getRawY() - ballFirstY)
    updateLayoutParams(floatingBall)
  end
  return false
end

-- 悬浮球点击展开
function Logo.onClick()
  expand()
end

-- 展开窗口拖动及外部点击处理
$ winFirstX, winFirstY, winWmX, winWmY

function Windows.OnTouchListener(v, event)
  $ action = event.getAction()
  if action == MotionEvent.ACTION_DOWN then
    winFirstX = event.getRawX()
    winFirstY = event.getRawY()
    winWmX = wmParams.x
    winWmY = wmParams.y
   elseif action == MotionEvent.ACTION_MOVE then
    wmParams.x = winWmX + (event.getRawX() - winFirstX)
    wmParams.y = winWmY + (event.getRawY() - winFirstY)
    updateLayoutParams(floatingWindow)
   elseif action == MotionEvent.ACTION_OUTSIDE then
    -- 点击悬浮窗外区域：自动最小化并返还焦点给其他应用
    hide()
    return true -- 消费事件
  end
  return false
end